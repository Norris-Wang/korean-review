import type { KnowledgeBase } from "./schema";

/**
 * Invariants checked after combining all lesson files, before DB sync.
 * New grammar examples should use cloze (e.g. "이것{이} 책상입니다.")
 * whenever focus occurs more than once within a sentence.
 */
export function getKnowledgeBaseErrors(kb: KnowledgeBase): string[] {
    const errors: string[] = [];
    const lessonIds = new Map<string, string>();

    const unique = (seen: Map<string, string>, id: string, path: string) => {
        if (!id.trim()) {
            errors.push(`${path}: ID 不能为空`);
            return;
        }
        const previous = seen.get(id);
        if (previous) {
            errors.push(`${path}: ID "${id}" 重复（首次出现于 ${previous}）`);
        } else {
            seen.set(id, path);
        }
    };

    for (const [li, lesson] of kb.lessons.entries()) {
        const base = `lessons[${li}] (${lesson.id})`;
        unique(lessonIds, lesson.id, base);
        const itemIds = new Map<string, string>();

        for (const [i, topic] of lesson.topics.entries()) {
            unique(itemIds, topic.id, `${base}.topics[${i}]`);
        }
        for (const [i, group] of lesson.vocabGroups.entries()) {
            const gp = `${base}.vocabGroups[${i}]`;
            unique(itemIds, group.id, gp);
            for (const [j, vocab] of group.items.entries()) {
                unique(itemIds, vocab.id, `${gp}.items[${j}]`);
            }
        }
        for (const [i, grammar] of lesson.grammars.entries()) {
            const gp = `${base}.grammars[${i}]`;
            unique(itemIds, grammar.id, gp);
            for (const [j, ex] of grammar.examples.entries()) {
                const ep = `${gp}.examples[${j}]`;
                if (!ex.focus) {
                    errors.push(`${ep}: focus 不能为空`);
                    continue;
                }
                if (!ex.answer) errors.push(`${ep}: answer 不能为空`);
                if (ex.cloze !== undefined) {
                    const marker = `{${ex.focus}}`;
                    if (ex.cloze.split(marker).length !== 2) {
                        errors.push(`${ep}: cloze 必须包含且仅包含一个 ${marker}`);
                    } else if (ex.cloze.replace(marker, ex.focus) !== ex.sentence) {
                        errors.push(`${ep}: cloze 无法还原原句`);
                    }
                } else if (ex.sentence.split(ex.focus).length !== 2) {
                    errors.push(`${ep}: focus "${ex.focus}" 无法唯一定位，请使用 cloze`);
                }
            }
        }
    }

    return errors;
}

export function assertKnowledgeBaseIntegrity(kb: KnowledgeBase): void {
    const errors = getKnowledgeBaseErrors(kb);
    if (errors.length) {
        throw new Error(`课程数据校验失败（${errors.length} 项）：\n${errors.join("\n")}`);
    }
}
